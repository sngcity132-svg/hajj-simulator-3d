import { Engine, Scene, Vector3, HemisphericLight, DirectionalLight, ArcRotateCamera,
  MeshBuilder, StandardMaterial, Color3, Color4, TransformNode, Scalar } from "@babylonjs/core";
import "./style.css";

const canvas = document.querySelector<HTMLCanvasElement>("#game")!;
const status = document.querySelector<HTMLDivElement>("#status")!;
const engine = new Engine(canvas, true, { antialias: true, stencil: true });
const scene = new Scene(engine);
scene.clearColor = new Color4(0.69, 0.77, 0.81, 1);
scene.collisionsEnabled = true;

const camera = new ArcRotateCamera("follow-camera", -Math.PI/2, 1.15, 14, new Vector3(0,1,0), scene);
camera.lowerRadiusLimit = 5; camera.upperRadiusLimit = 24;
camera.lowerBetaLimit = 0.45; camera.upperBetaLimit = 1.48;
camera.panningSensibility = 0; camera.attachControl(canvas, true);

const sky = new HemisphericLight("sky-light", new Vector3(0,1,0), scene); sky.intensity = .85;
const sun = new DirectionalLight("sun-light", new Vector3(-.5,-1,.3), scene); sun.intensity = 1.05;

function material(name:string, hex:string) {
  const m = new StandardMaterial(name, scene);
  m.diffuseColor = Color3.FromHexString(hex);
  m.specularColor = new Color3(.12,.12,.12);
  return m;
}
const stone = material("courtyard-stone","#d9d9d1");
const dark = material("kiswah-illustrative","#171817");
const gold = material("gold-details","#c5a04a");
const white = material("pilgrim-clothing","#f1efe6");
const skin = material("skin-tone-placeholder","#a87552");

const floor = MeshBuilder.CreateGround("courtyard-floor",{width:100,height:100},scene);
floor.material = stone; floor.checkCollisions = true;

// Blockout architecture only. Replace with reviewed modular GLB assets in the art phase.
function makeBox(name:string,w:number,h:number,d:number,x:number,y:number,z:number,mat:StandardMaterial) {
  const mesh = MeshBuilder.CreateBox(name,{width:w,height:h,depth:d},scene);
  mesh.position.set(x,y,z); mesh.material=mat; mesh.checkCollisions=true; return mesh;
}
for (const side of [-1,1]) {
  for (let i=-4;i<=4;i++) {
    makeBox("arcade-column",.65,7,.65,side*18,3.5,i*4.5,white);
  }
  makeBox("outer-gallery",1,1,42,side*21,.5,0,white);
}
for (let z of [-20,20]) {
  for (let i=-4;i<=4;i++) makeBox("arcade-column",.65,7,.65,i*4.5,3.5,z,white);
  makeBox("outer-gallery",42,1,1,0,.5,z,white);
}
makeBox("kaaba-illustrative",9,10,9,0,5,0,dark);
makeBox("kiswah-band-front",9.08,.55,.08,0,8.45,-4.56,gold);
makeBox("door-placeholder",1.35,2.8,.1,2.1,2.2,-4.58,gold);
const tawafGuide=MeshBuilder.CreateTorus("learning-route",{diameter:15,thickness:.045,tessellation:120},scene);
tawafGuide.rotation.x=Math.PI/2; tawafGuide.position.y=.04; tawafGuide.material=gold;

// Placeholder pilgrim. The character rig, clothing and locomotion animations are art/animation milestones.
const player = new TransformNode("player-root",scene);
const torso=MeshBuilder.CreateCapsule("player-body",{height:1.8,radius:.32},scene);
torso.parent=player; torso.position.y=.9; torso.material=white;
const head=MeshBuilder.CreateSphere("player-head",{diameter:.46},scene);
head.parent=player; head.position.y=1.95; head.material=skin;
player.position.set(0,0,-14);

let moveX=0, moveY=0, sprint=false;
const keys = new Set<string>();
window.addEventListener("keydown",e=>keys.add(e.key.toLowerCase()));
window.addEventListener("keyup",e=>keys.delete(e.key.toLowerCase()));

const touchPad=document.createElement("div");
touchPad.style.cssText="position:absolute;left:16px;bottom:20px;width:136px;height:136px;border-radius:50%;border:2px solid #ffffff88;background:#ffffff22;z-index:5;touch-action:none";
const knob=document.createElement("div");
knob.style.cssText="position:absolute;left:39px;top:39px;width:54px;height:54px;border-radius:50%;background:#d5b76c;border:2px solid white";
touchPad.append(knob); document.querySelector("main")!.append(touchPad);
let pointer:number|null=null;
touchPad.addEventListener("pointerdown",e=>{pointer=e.pointerId;touchPad.setPointerCapture(pointer);updateStick(e);});
touchPad.addEventListener("pointermove",e=>{if(pointer===e.pointerId)updateStick(e);});
function updateStick(e:PointerEvent){const r=touchPad.getBoundingClientRect(),dx=e.clientX-r.left-r.width/2,dy=e.clientY-r.top-r.height/2,max=43,len=Math.hypot(dx,dy),s=len>max?max/len:1;moveX=dx*s/max;moveY=-dy*s/max;knob.style.transform=`translate(${dx*s}px,${dy*s}px)`;}
function release(){pointer=null;moveX=moveY=0;knob.style.transform="translate(0,0)";}
touchPad.addEventListener("pointerup",release);touchPad.addEventListener("pointercancel",release);

const run=document.createElement("button");
run.textContent="Marche / course";
run.style.cssText="position:absolute;right:14px;bottom:22px;z-index:5;padding:13px;border-radius:12px;border:1px solid #d3b66d;background:#102d25;color:white;font-weight:700";
run.onclick=()=>{sprint=!sprint;run.textContent=sprint?"Course activée":"Marche / course"};
document.querySelector("main")!.append(run);

scene.onBeforeRenderObservable.add(()=>{
  const dt=Math.min(engine.getDeltaTime()/1000,.04);
  let x=moveX+(keys.has("d")?1:0)-(keys.has("a")?1:0);
  let y=moveY+(keys.has("w")?1:0)-(keys.has("s")?1:0);
  const len=Math.hypot(x,y); if(len>1){x/=len;y/=len;}
  const forward=new Vector3(-Math.sin(camera.alpha),0,-Math.cos(camera.alpha));
  const right=new Vector3(Math.cos(camera.alpha),0,-Math.sin(camera.alpha));
  const dir=forward.scale(y).add(right.scale(x));
  if(dir.lengthSquared()>.001){dir.normalize();player.position.addInPlace(dir.scale((sprint?6.5:3.2)*dt));player.rotation.y=Math.atan2(dir.x,dir.z);}
  player.position.x=Scalar.Clamp(player.position.x,-19,19);
  player.position.z=Scalar.Clamp(player.position.z,-19,19);
  camera.target=new Vector3(player.position.x,1.3,player.position.z);
});
engine.runRenderLoop(()=>scene.render());
window.addEventListener("resize",()=>engine.resize());
status.textContent="Niveau 01 — Exploration du Haram (blockout)";
