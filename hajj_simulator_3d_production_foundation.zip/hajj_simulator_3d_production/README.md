# HAJJ SIMULATOR 3D — Production Foundation

This package is the production foundation for a mobile-first 3D Hajj learning simulator.
It is **not yet a finished AAA game**. It defines the project structure, quality gates,
content governance and implementation sequence needed to build it responsibly.

## Current playable baseline
Use the `hajj_simulator_3d_prototype.zip` prototype as the current playable proof of concept.
This production package organizes the next development stages; it does not magically add
professional 3D assets, validated religious rulings, online infrastructure or AAA polish.

## Target platforms
- Primary: Android smartphones, browser/PWA delivery.
- Secondary: desktop browsers.
- Later: native Android/iOS packaging after performance and input systems are stable.

## Proposed stack
- Babylon.js + TypeScript
- glTF/GLB assets created in Blender
- Vite build tooling
- IndexedDB for local progress
- Optional authoritative multiplayer service in a later milestone

## Development commands
Install Node.js, then:
```bash
npm install
npm run dev
npm run build
```

## Production gates
1. A feature is not complete until tested on a real Android phone.
2. No religious instruction is published without traceable references and qualified review.
3. Sacred-site geometry must be labelled as illustrative unless verified against authoritative plans.
4. No leaderboard, score or reward may rank worshippers or imply spiritual merit.
5. Multiplayer must not be represented as available until a real server is deployed and tested.
