# Standard de validation des contenus religieux

Aucun texte de rite, invocation, translittération ou traduction ne doit être généré comme vérité religieuse sans validation.

Pour chaque entrée de contenu, conserver :
- identifiant stable ;
- nom arabe et français ;
- texte arabe exact, si applicable ;
- translittération relue ;
- traduction française ;
- source primaire ou référence bibliographique vérifiable ;
- degré d'authenticité lorsque pertinent ;
- école(s) juridique(s) concernée(s) ;
- distinction : pilier / obligation / acte recommandé / pratique variable ;
- nom ou comité du relecteur qualifié ;
- date de validation et version.

Les parcours du jeu sont pédagogiques. Le jeu ne délivre pas de fatwa et ne certifie pas la validité d'un pèlerinage réel.
