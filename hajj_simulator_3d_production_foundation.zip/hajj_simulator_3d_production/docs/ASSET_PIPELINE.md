# Pipeline des ressources 3D

## Formats
- Modèles statiques : glTF 2.0 / GLB.
- Textures : WebP/KTX2 selon le pipeline final.
- Audio : fichiers compressés et chargés à la demande.

## Règles de production
- Un modèle par module architectural réutilisable.
- Niveaux de détail (LOD) pour les éléments éloignés.
- Collisions simplifiées séparées du mesh visuel.
- Textures atlases et matériaux partagés pour les foules.
- Origine, échelle et orientation documentées.
- Autorisation/licence de chaque ressource enregistrée.

## Fidélité
Ne pas présenter une reconstruction comme exacte sans références architecturales fiables. Les éléments non vérifiés doivent rester clairement identifiés comme interprétation visuelle.
