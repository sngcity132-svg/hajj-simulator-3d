# Feuille de route de production

## Phase 0 — Fondations techniques
- Projet TypeScript/Vite/Babylon.js.
- Contrôles tactiles et clavier.
- Build reproductible.
- Test Android réel et profilage mémoire.

## Phase 1 — Vertical slice de qualité
Livrer un seul parcours complet et cohérent avant d'étendre le monde :
- zone extérieure et cour du Haram ;
- modèle Kaaba de qualité, réalisé à partir de références autorisées ;
- personnage riggé, animations marche/course/arrêt ;
- caméra troisième personne et caméra libre ;
- interactions contextuelles ;
- tutoriel de Tawaf avec étapes pédagogiques vérifiées ;
- sauvegarde locale et reprise de partie.

## Phase 2 — Contenu Hajj
- Ihram et préparation.
- Tawaf.
- Sa'i entre Safa et Marwa.
- Mina.
- Arafat.
- Muzdalifah.
- Jamarat.
- Rites de fin selon le type de Hajj.

Chaque rite doit être modélisé en étapes distinctes et conditionnelles. Les différences juridiques entre écoles doivent être visibles et sourcées ; aucune règle ne doit être déduite par le développeur.

## Phase 3 — Monde et personnages
- Zones séparées chargées à la demande.
- LOD, occlusion, atlases de textures, compression des textures.
- Foules instanciées avec densité réglable.
- Navigation NPC, évitement et comportements simples.
- Audio spatial et sous-titres.

## Phase 4 — Multijoueur
- Serveur autoritaire, authentification et salons privés.
- Synchronisation position/animation.
- Modération, confidentialité et reconnexion.
- Tests de charge avant toute annonce publique.

## Phase 5 — Pré-lancement
- Tests Android bas/milieu/haut de gamme.
- Tests hors-ligne et réseau faible.
- Audit de sécurité et de confidentialité.
- Relecture religieuse et architecturale.
- Accessibilité : taille des textes, sous-titres, langues.
